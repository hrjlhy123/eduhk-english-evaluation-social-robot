import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { importAll, importRes } from './index'
import './resources/sass/App.sass'

class Page3 extends React.Component {
  constructor (props) {
    super(props)
    let imagesURL = importAll(
      require.context('./resources/images_avif/Page3/', false, /\.(avif|svg|png|jpe?g)$/)
    )
    this.state = {
      images: importRes('image', imagesURL),
      score: null,
      fluency: null,
      integrity: null,
      accuracy: null
    }
  }

  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        if (sessionStorage.getItem('integrity') != null) {
          clearInterval(intervalId)
        }
        return {
          score: sessionStorage.getItem('score'),
          fluency: sessionStorage.getItem('fluency'),
          integrity: sessionStorage.getItem('integrity'),
          accuracy: sessionStorage.getItem('accuracy')
        }
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    let star = []
    if (this.state.score >= 80) {
      star[3] = {
        display: 'initial'
      }
    } else if (this.state.score >= 60) {
      star[2] = {
        display: 'initial'
      }
    } else if (this.state.score >= 20) {
      star[1] = {
        display: 'initial'
      }
    }
    return (
      <div className='App-Page3'>
        {this.state.images.map(item => {
          switch (item.class) {
            case 'star_bg':
            case 'rectangle2':
            case 'star': {
              return (
                <div>
                  {[1, 2, 3].map(i => {
                    return (
                      <img
                        src={item.src}
                        className={'App-' + item.class + i}
                        style={item.class == 'star' ? star[i] : {}}
                      />
                    )
                  })}
                </div>
              )
            }
            case 'icon7':
              return (
                <Link to='/Page4'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            case 'icon8':
              return (
                <Link to='/'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            default:
              return <img src={item.src} className={'App-' + item.class} />
          }
        })}
        <div className='App-Scoreboard'>
          <div className='Scoreboard-items'>
            <p>SCORE</p>
            <p>{this.state.score || '-'}</p>
          </div>
          <div>
            <div className='Scoreboard-items'>
              <p>FLUENCY</p>
              <p>{this.state.fluency || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>INTEGRITY</p>
              <p>{this.state.integrity || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>ACCURACY</p>
              <p>{this.state.accuracy || '-'}</p>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Page3

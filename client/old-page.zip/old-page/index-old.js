import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom'
import reportWebVitals from './reportWebVitals'
import App from './App'
import Page1 from './Page1'
import Page2 from './Page2'
import Page3 from './Page3'
import Page4 from './Page4'
import ReactPWAInstallProvider, { useReactPWAInstall } from 'react-pwa-install'
/* import core */
export function importAll (r) {
  return r.keys().map(r)
}
/* import Resource */
export function importRes (type, urls) {
  let res = [],
    res_preload = [],
    url = [],
    name = []
  console.log(urls)
  for (var o in urls) {
    name[o] = urls[o]
      .split('/')
      .pop()
      .split('.')[0]
    // import image
    switch (type) {
      case 'image':
        res_preload[o] = new Image()
        break
      case 'voice':
        res_preload[o] = new Audio()
      default:
        break
    }
    res_preload[o].src = url[o] = urls[o]
    res[o] = { class: name[o], src: url[o] }
  }
  return res
}

const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(
  <ReactPWAInstallProvider enableLogging>
    <React.StrictMode>
      <Router>
        <Routes>
          <Route path='/' element={<Page1 />} />
          <Route path='/Page2' element={<Page2 />} />
          <Route path='/Page3' element={<Page3 />} />
          <Route path='/Page4' element={<Page4 />} />
        </Routes>
      </Router>
    </React.StrictMode>
  </ReactPWAInstallProvider>
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals()

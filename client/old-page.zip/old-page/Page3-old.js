/* import components */
import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

/* import scss */
import './resources/sass/App.sass'

/* import core */
function importAll (r) {
  return r.keys().map(r)
}

/* import voices */
let voices = {}
const voicesURL = importAll(
  require.context('./resources/voices/', false, /\.(wav|mp3)$/)
)

for (var url of voicesURL) {
  let voiceName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import voice
  voices[voiceName] = url
}
// console.log(voices)

/* import images */
let images = {}
const imagesURL = importAll(
  require.context('./resources/images_avif/', false, /\.(avif|svg|png|jpe?g)$/)
)
for (var url of imagesURL) {
  let imageName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import image
  images[imageName] = url
}
// console.log(images)

class Page3 extends React.Component {
  // Initialization state
  state = { score: null, fluency: null, integrity: null, accuracy: null }
  // Consistent score acquisition
  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        if (sessionStorage.getItem('integrity') != null) {
          clearInterval(intervalId)
        }
        return {
          score: sessionStorage.getItem('score'),
          fluency: sessionStorage.getItem('fluency'),
          integrity: sessionStorage.getItem('integrity'),
          accuracy: sessionStorage.getItem('accuracy')
        }
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    let star1,
      star2,
      star3 = {}
    if (this.state.score >= 80) {
      star3 = {
        display: 'initial'
      }
    }
    if (this.state.score >= 60) {
      star2 = {
        display: 'initial'
      }
    }
    if (this.state.score >= 15) {
      star1 = {
        display: 'initial'
      }
    }
    return (
      <div className='App-Page3'>
        <img
          src={images['background3']}
          className='App-background3'
          alt='background3'
        />
        <img src={images['box3']} className='App-box3' alt='box3' />
        <img src={images['star_bg']} className='App-star_bg1' alt='star_bg' />
        <img src={images['star_bg']} className='App-star_bg2' alt='star_bg' />
        <img src={images['star_bg']} className='App-star_bg3' alt='star_bg' />
        <img
          src={images['star']}
          className='App-star1'
          alt='star'
          style={star1}
        />
        <img
          src={images['star']}
          className='App-star2'
          alt='star'
          style={star2}
        />
        <img
          src={images['star']}
          className='App-star3'
          alt='star'
          style={star3}
        />
        <img
          src={images['rectangle1']}
          className='App-rectangle1'
          alt='rectangle1'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle2'
          alt='rectangle2'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle3'
          alt='rectangle2'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle4'
          alt='rectangle2'
        />
        <div className='App-Scoreboard'>
          <div className='Scoreboard-items'>
            <p>SCORE</p>
            <p>{this.state.score || '-'}</p>
          </div>
          <div>
            <div className='Scoreboard-items'>
              <p>FLUENCY</p>
              <p>{this.state.fluency || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>INTEGRITY</p>
              <p>{this.state.integrity || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>ACCURACY</p>
              <p>{this.state.accuracy || '-'}</p>
            </div>
          </div>
        </div>
        <Link to='/Page4'>
          <img src={images['icon7']} className='App-icon7' alt='icon7' />
        </Link>
        <Link to='/'>
          <img src={images['icon8']} className='App-icon8' alt='icon8' />
        </Link>
        <img
          src={images['sentence2']}
          className='App-sentence2'
          alt='sentence2'
        />
        <img src={images['title2']} className='App-title2' alt='title2' />
      </div>
    )
  }
}

export default Page3
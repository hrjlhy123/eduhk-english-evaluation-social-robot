/* import components */
import React, { useRef, useEffect, useState } from 'react'
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  BrowserRouter
} from 'react-router-dom'

/* import Chivox component */
import Html5Player from 'chivox_h5sdk/src/html5/html5player'
import Html5Recorder from 'chivox_h5sdk/src/html5/html5recorder'

/* import scss */
import './resources/sass/App.sass'

/* import core */
function importAll (r) {
  return r.keys().map(r)
}

/* import voices */
let voices = {}
const voicesURL = importAll(
  require.context('./resources/voices/', false, /\.(wav|mp3)$/)
)

for (var url of voicesURL) {
  let voiceName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import voice
  voices[voiceName] = url
}
console.log(voices)

/* import images */
let images = {}
const imagesURL = importAll(
  require.context('./resources/images_avif/', false, /\.(avif|svg|png|jpe?g)$/)
)
for (var url of imagesURL) {
  let imageName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import image
  images[imageName] = url
}
console.log(images)

class Page1 extends React.Component {
  render () {
    // Long time use will be stuck???
    let imagesList = imagesURL.map(url => {
      return <img src={url} key={url}></img>
    })
    let voicesList = voicesURL.map(url => {
      return <audio src={url} key={url}></audio>
    })
    return (
      <div className='App-Page1'>
        <div className='preload'>
          {imagesList}
          {voicesList}
        </div>
        <img
          src={images['background1']}
          className='App-background1'
          alt='background1'
        />
        <img src={images['box1']} className='App-box1' alt='box1' />
        <img src={images['icon1']} className='App-icon1' alt='icon1' />
        <img src={images['icon2']} className='App-icon2' alt='icon2' />
        <img src={images['picture1']} className='App-picture1' alt='picture1' />
        <img
          src={images['special_icon1']}
          className='App-special_icon1'
          alt='special_icon1'
        />
        <img
          src={images['special_icon2']}
          className='App-special_icon2'
          alt='special_icon2'
        />
        <img src={images['title1']} className='App-title1' alt='title1' />
        <img
          src={images['sentence1']}
          className='App-sentence1'
          alt='sentence1'
        />
        {/* <img src={images['cache1']} className='cache1' alt='cache1' />
        <img src={images['cache2']} className='cache2' alt='cache2' />
        <img src={images['cache3']} className='cache3' alt='cache3' /> */}
        <Link to='/Page2'>
          <img
            src={images['selection1']}
            className='App-selection1'
            alt='selection1'
            onClick={() => {
              document.body.style.backgroundImage =
                'url("' + images['cache4'] + '")'
            }}
          />
        </Link>
        <img
          src={images['selection2']}
          className='App-selection2'
          alt='selection2'
        />
        <img
          src={images['selection3']}
          className='App-selection3'
          alt='selection3'
        />
      </div>
    )
  }
}

class Page2 extends React.Component {
  constructor (props) {
    // Initialization Chivox API
    super(props)
    this.state = {
      refText: 'Once upon a time, there lived three little pigs. ',
      refAudio: new Audio(voices['na_001']),
      recorder: [
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Sentence Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        }),
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Free Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        })
      ],
      audio: new Audio(voices['001_na']),
      recordFlag: true
    }
    this.handleClick = this.handleClick.bind(this)
  }

  // Bind Click Event
  handleClick () {
    console.log('Button clicked')
    // Play audio
    this.state.refAudio.play()
    console.log(this.state.refAudio.duration)
    // Recording after audio
    setTimeout(() => {
      if (this.state.recordFlag) {
        this.state.recordFlag = false
        // Calling Sentence Scoring Interface
        this.state.recorder[0].stopRecord()
        this.state.recorder[0].record({
          duration: 8000,
          playDing: true,
          serverParams: {
            coreType: 'en.sent.score',
            refText: this.state.refText,
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
          },
          onStop: () => {
            console.log('onStop')
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            console.log(JSON.stringify(score.result.details))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem(
              'words',
              JSON.stringify(score.result.details)
            )
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
            // Integrity
            sessionStorage.setItem('integrity', score.result.integrity)
            // Accuracy
            sessionStorage.setItem('accuracy', score.result.accuracy)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            this.state.recorder[0].reset()
            alert(JSON.stringify(err))
          }
        })

        // Calling the Free Scoring Interface
        this.state.recorder[1].stopRecord()
        this.state.recorder[1].record({
          duration: 8000,
          playDing: false,
          serverParams: {
            coreType: 'en.asr.rec',
            res: 'en.asr.G4',
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1,
            result: {
              details: {
                ext_cur_wrd: 1
              }
            }
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
            sessionStorage.clear()
          },
          onStop: () => {
            console.log('onStop')
          },
          onInternalScore: score => {
            console.log('onInternalScore')
            console.log(JSON.stringify(score.result.align))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem('words', JSON.stringify(score.result.align))
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            // console.log(score.result)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            this.state.recorder[1].reset()
            alert(JSON.stringify(err))
          }
        })
      } else {
        this.state.recordFlag = true
        this.state.recorder[1].stopRecord()
        console.log('record stop.')
      }
    }, this.state.refAudio.duration * 1.3 * 1000 || 0) /* Delay 1.3 time before calling Chivox API */
  }

  render () {
    return (
      <div className='App-Page2'>
        {/* <Link to='/Page3'>
          <img
            src={images['background2']}
            className='App-background2'
            alt='background2'
          />
        </Link> */}
        <div className='Stage'>
          <div className='Frame1'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig1']} className='App-pig1' alt='pig1' />
            <img src={images['pig2']} className='App-pig2' alt='pig2' />
            <img src={images['pig3']} className='App-pig3' alt='pig3' />
          </div>
          <div className='Frame2'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig4']} className='App-pig1' alt='pig1' />
          </div>
          <div className='Frame3'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig5']} className='App-pig1' alt='pig1' />
          </div>
          <div className='Frame4'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig6']} className='App-pig1' alt='pig1' />
          </div>
        </div>
        <img src={images['box2']} className='App-box2' alt='box2' />
        <Link to='/'>
          <img src={images['icon3']} className='App-icon3' alt='icon3' />
        </Link>
        <img src={images['icon4']} className='App-icon4' alt='icon4' />
        <img src={images['icon5']} className='App-icon5' alt='icon5' />
        <div className='App-subtitle1'>
          <p>{this.state.refText}</p>
        </div>
        <img
          src={images['icon6']}
          className='App-icon6'
          alt='icon6'
          onClick={this.handleClick}
        />
        {/* <img src={icon6} className='App-icon6' alt='icon6' ref={ref} /> */}
      </div>
    )
  }
}

class Page3 extends React.Component {
  // Initialization state
  state = { score: null, fluency: null, integrity: null, accuracy: null }
  // Consistent score acquisition
  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        if (sessionStorage.getItem('integrity') != null) {
          clearInterval(intervalId)
        }
        return {
          score: sessionStorage.getItem('score'),
          fluency: sessionStorage.getItem('fluency'),
          integrity: sessionStorage.getItem('integrity'),
          accuracy: sessionStorage.getItem('accuracy')
        }
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    let star1,
      star2,
      star3 = {}
    if (this.state.score >= 80) {
      star3 = {
        display: 'initial'
      }
    }
    if (this.state.score >= 60) {
      star2 = {
        display: 'initial'
      }
    }
    if (this.state.score >= 15) {
      star1 = {
        display: 'initial'
      }
    }
    return (
      <div className='App-Page3'>
        <img
          src={images['background3']}
          className='App-background3'
          alt='background3'
        />
        <img src={images['box3']} className='App-box3' alt='box3' />
        <img src={images['star_bg']} className='App-star_bg1' alt='star_bg' />
        <img src={images['star_bg']} className='App-star_bg2' alt='star_bg' />
        <img src={images['star_bg']} className='App-star_bg3' alt='star_bg' />
        <img
          src={images['star']}
          className='App-star1'
          alt='star'
          style={star1}
        />
        <img
          src={images['star']}
          className='App-star2'
          alt='star'
          style={star2}
        />
        <img
          src={images['star']}
          className='App-star3'
          alt='star'
          style={star3}
        />
        <img
          src={images['rectangle1']}
          className='App-rectangle1'
          alt='rectangle1'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle2'
          alt='rectangle2'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle3'
          alt='rectangle2'
        />
        <img
          src={images['rectangle2']}
          className='App-rectangle4'
          alt='rectangle2'
        />
        <div className='App-Scoreboard'>
          <div className='Scoreboard-items'>
            <p>SCORE</p>
            <p>{this.state.score || '-'}</p>
          </div>
          <div>
            <div className='Scoreboard-items'>
              <p>FLUENCY</p>
              <p>{this.state.fluency || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>INTEGRITY</p>
              <p>{this.state.integrity || '-'}</p>
            </div>
            <div className='Scoreboard-items'>
              <p>ACCURACY</p>
              <p>{this.state.accuracy || '-'}</p>
            </div>
          </div>
        </div>
        <Link to='/Page4'>
          <img src={images['icon7']} className='App-icon7' alt='icon7' />
        </Link>
        <Link to='/'>
          <img src={images['icon8']} className='App-icon8' alt='icon8' />
        </Link>
        <img
          src={images['sentence2']}
          className='App-sentence2'
          alt='sentence2'
        />
        <img src={images['title2']} className='App-title2' alt='title2' />
      </div>
    )
  }
}

class Page4 extends React.Component {
  // Initialization state
  constructor (props) {
    super(props)
    let sentences = sessionStorage.getItem('sentences')
    let words = JSON.parse(sessionStorage.getItem('words'))
    this.state = { words }
  }
  // Consistent score acquisition
  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        let words = JSON.parse(sessionStorage.getItem('words'))
        if (words && words[0].char != null) {
          clearInterval(intervalId)
        }
        return {
          words: words
        }
        console.log(this.state)
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    return (
      <div className='App-Page4'>
        <img
          src={images['background4']}
          className='App-background4'
          alt='background4'
        />
        <img src={images['box4']} className='App-box4' alt='box4' />
        <Link to='/Page3'>
          <img src={images['icon1']} className='App-icon1' alt='icon1' />
        </Link>
        <img src={images['icon4']} className='App-icon4' alt='icon4' />
        <img src={images['icon5']} className='App-icon5' alt='icon5' />
        <img src={images['picture2']} className='App-picture2' alt='picture2' />
        <img src={images['title3']} className='App-title3' alt='title3' />
        <div className='App-subtitle2'>
          {this.state.words
            ? this.state.words.map((item, index) => {
                if (item.score >= 60) {
                  return (
                    <span className='word' key={index}>
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                    </span>
                  )
                } else if (item.score == 0) {
                  return (
                    <span
                      className='word'
                      key={index}
                      style={{
                        color: '#F55D5E'
                      }}
                    >
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                      <img
                        src={images['mark1']}
                        className='App-mark1'
                        alt='mark1'
                      />
                    </span>
                  )
                } else {
                  return (
                    <span
                      className='word'
                      key={index}
                      style={{
                        color: '#00CAFF'
                      }}
                    >
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                      <img
                        src={images['mark2']}
                        className='App-mark2'
                        alt='mark2'
                      />
                    </span>
                  )
                }
              })
            : ''}
        </div>
      </div>
    )
  }
}

export default Page1

// function Page2 () {
//   // Initialization Chivox API
//   let refText = 'Once upon a time, there lived three little pigs. '
//   let player = new Html5Player()
//   let recorder = []
//   recorder[0] = new Html5Recorder({
//     server: 'wss://cloud.chivox.com',
//     appKey: '1649755076000093',
//     sigurl: '/key',
//     onInit: mess => {
//       console.log('Sentence Scoring API onInit success')
//     },
//     onError: err => {
//       console.log('onError: ' + err)
//     }
//   })
//   recorder[1] = new Html5Recorder({
//     server: 'wss://cloud.chivox.com',
//     appKey: '1649755076000093',
//     sigurl: '/key',
//     onInit: mess => {
//       console.log('Free Scoring API onInit success')
//     },
//     onError: err => {
//       console.log('onError: ' + err)
//     }
//   })
//   let recordFlag = true
//   // Import Audio
//   let audio = new Audio(na_001)

//   // Trigger click event
//   const ref = useRef(null)
//   useEffect(() => {
//     const handleClick = event => {
//       console.log('Button clicked')
//       // Play audio
//       audio.play()
//       console.log(audio.duration)
//       setTimeout(() => {
//         if (recordFlag) {
//           recordFlag = false
//           // Calling the Sentence Scoring Interface
//           recorder[0].stopRecord()
//           recorder[0].record({
//             duration: 8000,
//             playDing: true,
//             serverParams: {
//               coreType: 'en.sent.score',
//               refText: refText,
//               rank: 100,
//               userId: 'tester',
//               attachAudioUrl: 1
//             },
//             onRecordIdGenerated: tokenId => {
//               console.log('========onRecordIdGenerated start========')
//               console.log(JSON.stringify(tokenId))
//               console.log('========onRecordIdGenerated end========')
//             },
//             onStart: () => {
//               console.log('onStart')
//             },
//             onStop: () => {
//               console.log('onStop')
//             },
//             onScore: score => {
//               recordFlag = true
//               recorder[0].stopRecord()
//               console.log(JSON.stringify(score.result.details))
//               // Sentences
//               sessionStorage.setItem('sentences', refText)
//               // Words
//               sessionStorage.setItem(
//                 'words',
//                 JSON.stringify(score.result.details)
//               )
//               // Score
//               sessionStorage.setItem('score', score.result.overall)
//               // Fluency
//               sessionStorage.setItem('fluency', score.result.fluency.overall)
//               // Integrity
//               sessionStorage.setItem('integrity', score.result.integrity)
//               // Accuracy
//               sessionStorage.setItem('accuracy', score.result.accuracy)
//             },
//             onScoreError: err => {
//               recordFlag = true
//               recorder[0].stopRecord()
//               recorder[0].reset()
//               alert(JSON.stringify(err))
//             }
//           })

//           // Calling the Free Scoring Interface
//           recorder[1].stopRecord()
//           recorder[1].record({
//             duration: 8000,
//             playDing: true,
//             serverParams: {
//               coreType: 'en.asr.rec',
//               res: 'en.asr.G4',
//               rank: 100,
//               userId: 'tester',
//               attachAudioUrl: 1,
//               result: {
//                 details: {
//                   ext_cur_wrd: 1
//                 }
//               }
//             },
//             onRecordIdGenerated: tokenId => {
//               console.log('========onRecordIdGenerated start========')
//               console.log(JSON.stringify(tokenId))
//               console.log('========onRecordIdGenerated end========')
//             },
//             onStart: () => {
//               console.log('onStart')
//               sessionStorage.clear()
//             },
//             onStop: () => {
//               console.log('onStop')
//             },
//             onInternalScore: score => {
//               console.log('onInternalScore')
//               console.log(JSON.stringify(score.result.align))
//               // Sentences
//               sessionStorage.setItem('sentences', refText)
//               // Words
//               sessionStorage.setItem(
//                 'words',
//                 JSON.stringify(score.result.align)
//               )
//               // Score
//               sessionStorage.setItem('score', score.result.overall)
//               // Fluency
//               sessionStorage.setItem('fluency', score.result.fluency.overall)
//             },
//             onScore: score => {
//               recordFlag = true
//               recorder[1].stopRecord()
//               // console.log(score.result)
//             },
//             onScoreError: err => {
//               recordFlag = true
//               recorder[1].stopRecord()
//               recorder[1].reset()
//               alert(JSON.stringify(err))
//             }
//           })
//         } else {
//           recordFlag = true
//           recorder[1].stopRecord()
//           console.log('record stop.')
//         }
//       }, (audio.duration + 0.8) * 1000 || 0) /* Audio time + delay time before calling Chivox API */
//     }
//     const element = ref.current
//     element.addEventListener('click', handleClick)
//     return () => {
//       element.removeEventListener('click', handleClick)
//     }
//   }, [])
//   return (
//     <div className='App-Page2'>
//       <Link to='/Page3'>
//         <img src={background2} className='App-background2' alt='background2' />
//       </Link>
//       <img src={pig1} className='App-pig1' alt='pig1' />
//       <img src={pig2} className='App-pig2' alt='pig2' />
//       <img src={pig3} className='App-pig3' alt='pig3' />
//       <img src={box2} className='App-box2' alt='box2' />
//       <Link to='/'>
//         <img src={icon3} className='App-icon3' alt='icon3' />
//       </Link>
//       <img src={icon4} className='App-icon4' alt='icon4' />
//       <img src={icon5} className='App-icon5' alt='icon5' />
//       <div className='App-subtitle1'>
//         <p>{refText}</p>
//       </div>
//       <img src={icon6} className='App-icon6' alt='icon6' ref={ref} />
//     </div>
//   )
// }

/* tutorial-link to Node.js */
// import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';

// className App extends Component {
//   state = { data: null };

//   componentDidMount() {
//     this.callBackendAPI()
//       .then(res => this.setState({ data: res.express }))
//       .catch(err => console.log(err));
//   }
//   // fetching the GET route from the Express server which matches the GET route from server.js
//   callBackendAPI = async () => {
//     const response = await fetch('/express_backend');
//     const body = await response.json();

//     if (response.status !== 200) {
//       throw Error(body.message)
//     }
//     return body;
//   };

//   render() {
//     return (
//       <div className="App">
//         <header className="App-header">
//           <img src={logo} className="App-logo" alt="logo" />
//           <h1 className="App-title">Welcome to React</h1>
//         </header>
//         <p className="App-intro">{this.state.data}</p>
//       </div>
//     );
//   }
// }

// export default App;

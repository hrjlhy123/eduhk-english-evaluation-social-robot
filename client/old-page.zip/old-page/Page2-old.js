/* import components */
import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

/* import Chivox component */
import Html5Player from 'chivox_h5sdk/src/html5/html5player'
import Html5Recorder from 'chivox_h5sdk/src/html5/html5recorder'

/* import scss */
import './resources/sass/App.sass'

/* import core */
function importAll (r) {
  return r.keys().map(r)
}

/* import voices */
let voices = {}
const voicesURL = importAll(
  require.context('./resources/voices/', false, /\.(wav|mp3)$/)
)

for (var url of voicesURL) {
  let voiceName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import voice
  voices[voiceName] = url
}
// console.log(voices)

/* import images */
let images = {}
const imagesURL = importAll(
  require.context('./resources/images_avif/', false, /\.(avif|svg|png|jpe?g)$/)
)
for (var url of imagesURL) {
  let imageName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import image
  images[imageName] = url
}
// console.log(images)

class Page2 extends React.Component {
  constructor (props) {
    // Initialization Chivox API
    super(props)
    this.state = {
      refText: 'Once upon a time, there lived three little pigs. ',
      refAudio: new Audio(voices['na_001']),
      recorder: [
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Sentence Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        }),
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Free Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        })
      ],
      audio: new Audio(voices['001_na']),
      recordFlag: true
    }
    // Bind click function
    this.handleClick1 = this.handleClick1.bind(this)
    this.handleClick2 = this.handleClick2.bind(this)
  }
  componentDidMount (props) {
    // alert("a")
    // Initialize page 1
    // document.querySelector('.App-icon4').style.display = 'none'
    // document.querySelector('.Story-Page1').style.display = 'initial'
  }
  // Click: Next page
  handleClick1 () {
    document.querySelector(
      '.Story-Page[style * ="display:initial;"]'
    ).style.display = 'none'
    console.log(
      document.querySelector(
        '.Story-Page[style * ="display:initial;"] + .Story-Page'
      )
    )
  }
  // Click: Record
  handleClick2 () {
    console.log('Button clicked')
    // Play audio
    this.state.refAudio.play()
    console.log(this.state.refAudio.duration)
    // Recording after audio
    setTimeout(() => {
      if (this.state.recordFlag) {
        this.state.recordFlag = false
        // Calling Sentence Scoring Interface
        this.state.recorder[0].stopRecord()
        this.state.recorder[0].record({
          duration: 8000,
          playDing: true,
          serverParams: {
            coreType: 'en.sent.score',
            refText: this.state.refText,
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
          },
          onStop: () => {
            console.log('onStop')
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            console.log(JSON.stringify(score.result.details))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem(
              'words',
              JSON.stringify(score.result.details)
            )
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
            // Integrity
            sessionStorage.setItem('integrity', score.result.integrity)
            // Accuracy
            sessionStorage.setItem('accuracy', score.result.accuracy)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            this.state.recorder[0].reset()
            alert(JSON.stringify(err))
          }
        })

        // Calling the Free Scoring Interface
        this.state.recorder[1].stopRecord()
        this.state.recorder[1].record({
          duration: 8000,
          playDing: false,
          serverParams: {
            coreType: 'en.asr.rec',
            res: 'en.asr.G4',
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1,
            result: {
              details: {
                ext_cur_wrd: 1
              }
            }
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
            sessionStorage.clear()
          },
          onStop: () => {
            console.log('onStop')
          },
          onInternalScore: score => {
            console.log('onInternalScore')
            console.log(JSON.stringify(score.result.align))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem('words', JSON.stringify(score.result.align))
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            // console.log(score.result)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            this.state.recorder[1].reset()
            alert(JSON.stringify(err))
          }
        })
      } else {
        this.state.recordFlag = true
        this.state.recorder[1].stopRecord()
        console.log('record stop.')
      }
    }, this.state.refAudio.duration * 1.3 * 1000 || 0) /* Delay 1.3 time before calling Chivox API */
  }

  render () {
    return (
      <div className='App-Page2'>
        <img
          src={images['background2']}
          className='App-background2'
          alt='background2'
        />
        <div className='Story'>
          {/* Page1 */}
          <div className='Story-Page'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig1']} className='App-pig1' alt='pig1' />
            <img src={images['pig2']} className='App-pig2' alt='pig2' />
            <img src={images['pig3']} className='App-pig3' alt='pig3' />
          </div>
          {/* Page2 */}
          <div className='Story-Page'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig4']} className='App-pig1' alt='pig1' />
          </div>
          {/* Page3 */}
          <div className='Story-Page'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <img src={images['pig5']} className='App-pig1' alt='pig1' />
          </div>
          {/* Page4 */}
          <div className='Story-Page'>
            <img
              src={images['background2']}
              className='App-background2'
              alt='background2'
            />
            <Link to='/Page3'>
              <img src={images['pig6']} className='App-pig1' alt='pig1' />
            </Link>
          </div>
        </div>
        <img src={images['box2']} className='App-box2' alt='box2' />
        <Link to='/'>
          <img src={images['icon3']} className='App-icon3' alt='icon3' />
        </Link>
        <img src={images['icon4']} className='App-icon4' alt='icon4' />
        <button onClick={this.handleClick1}>
          <img src={images['icon5']} className='App-icon5' alt='icon5' />
        </button>
        <div className='App-subtitle1'>
          <p>{this.state.refText}</p>
        </div>
        <img
          src={images['icon6']}
          className='App-icon6'
          alt='icon6'
          onClick={this.handleClick2}
        />
        {/* <img src={icon6} className='App-icon6' alt='icon6' ref={ref} /> */}
      </div>
    )
  }
}

export default Page2

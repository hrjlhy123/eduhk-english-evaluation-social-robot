/* import components */
import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

/* import scss */
import './resources/sass/App.sass'

/* import core */
function importAll (r) {
  return r.keys().map(r)
}

/* import voices */
let voices = {}
const voicesURL = importAll(
  require.context('./resources/voices/', false, /\.(wav|mp3)$/)
)

for (var url of voicesURL) {
  let voiceName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import voice
  voices[voiceName] = url
}
// console.log(voices)

/* import images */
let images = {}
const imagesURL = importAll(
  require.context('./resources/images_avif/', false, /\.(avif|svg|png|jpe?g)$/)
)
for (var url of imagesURL) {
  let imageName = url
    .split('/')
    .pop()
    .split('.')[0]
  // import image
  images[imageName] = url
}
// console.log(images)

class Page4 extends React.Component {
  // Initialization state
  constructor (props) {
    super(props)
    let sentences = sessionStorage.getItem('sentences')
    let words = JSON.parse(sessionStorage.getItem('words'))
    this.state = { words }
  }
  // Consistent score acquisition
  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        let words = JSON.parse(sessionStorage.getItem('words'))
        if (words && words[0].char != null) {
          clearInterval(intervalId)
        }
        return {
          words: words
        }
        console.log(this.state)
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    return (
      <div className='App-Page4'>
        <img
          src={images['background4']}
          className='App-background4'
          alt='background4'
        />
        <img src={images['box4']} className='App-box4' alt='box4' />
        <Link to='/Page3'>
          <img src={images['icon1']} className='App-icon1' alt='icon1' />
        </Link>
        <img src={images['icon4']} className='App-icon4' alt='icon4' />
        <img src={images['icon5']} className='App-icon5' alt='icon5' />
        <img src={images['picture2']} className='App-picture2' alt='picture2' />
        <img src={images['title3']} className='App-title3' alt='title3' />
        <div className='App-subtitle2'>
          {this.state.words
            ? this.state.words.map((item, index) => {
                if (item.score >= 60) {
                  return (
                    <span className='word' key={index}>
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                    </span>
                  )
                } else if (item.score == 0) {
                  return (
                    <span
                      className='word'
                      key={index}
                      style={{
                        color: '#F55D5E'
                      }}
                    >
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                      <img
                        src={images['mark1']}
                        className='App-mark1'
                        alt='mark1'
                      />
                    </span>
                  )
                } else {
                  return (
                    <span
                      className='word'
                      key={index}
                      style={{
                        color: '#00CAFF'
                      }}
                    >
                      <span>{item.score}</span>
                      <span>{item.char || item.txt}</span>
                      <img
                        src={images['mark2']}
                        className='App-mark2'
                        alt='mark2'
                      />
                    </span>
                  )
                }
              })
            : ''}
        </div>
      </div>
    )
  }
}

export default Page4

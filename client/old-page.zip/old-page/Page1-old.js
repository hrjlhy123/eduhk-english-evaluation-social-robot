/* import components */
import React, { useRef, useEffect, useState } from 'react'
import * as ReactDOM from 'react-dom/client'
import { Link } from 'react-router-dom'
// import background from './resources/images_avif/background1.svg'
// import box1 from './resources/images_avif/box1.svg'
// import icon1 from './resources/images_avif/icon1.svg'
// import icon2 from './resources/images_avif/icon2.svg'
// import picture from './resources/images_avif/picture1.svg'
// import special_icon1 from './resources/images_avif/special_icon1.svg'
// import special_icon2 from './resources/images_avif/special_icon2.svg'
// import title from './resources/images_avif/title1.png'
// import subtitle from './resources/images_avif/sentence1.svg'
// import selection1 from './resources/images_avif/selection1.svg'
// import selection2 from './resources/images_avif/selection2.svg'
// import selection3 from './resources/images_avif/selection3.svg'

/* import scss */
import './resources/sass/App.sass'

/* import voices */
// let voices = {}
// const voicesURL = importAll(
//   require.context('./resources/voices/', false, /\.(wav|mp3)$/)
// )
// for (var url of voicesURL) {
//   let voiceName = url
//     .split('/')
//     .pop()
//     .split('.')[0]
//   // import voice
//   voices[voiceName] = url
// }
// console.log(voices)

/* import images */
// let images = {}
// const imagesURL = importAll(
//   require.context('./resources/images_avif/', false, /\.(avif|svg|png|jpe?g)$/)
// )
// for (var url of imagesURL) {
//   let imageName = url
//     .split('/')
//     .pop()
//     .split('.')[0]
//   // import image
//   images[imageName] = url
// }
// console.log(images)
/* import core */
function importAll (r) {
  return r.keys().map(r)
}
/* import image */
let image = [],
  image_preload = [],
  imageURL = [],
  imageName = []
const imagesURL = importAll(
  require.context('./resources/images_avif/Page1', false, /\.(avif|svg|png|jpe?g)$/)
)
class Page1 extends React.Component {
  constructor (props) {
    super(props)
    this.state = { images: image }
  }

  componentDidMount () {
    for (var o in imagesURL) {
      imageName[o] = imagesURL[o]
        .split('/')
        .pop()
        .split('.')[0]
      // import image
      image_preload[o] = new Image()
      image_preload[o].src = imagesURL[o]
      imageURL[o] = imagesURL[o]
      image[o] = { class: imageName[o], src: imageURL[o] }
    }
    this.setState({ images: image })
    // console.log(this.state.images)
    // this.state.images.map(imageURL => console.log("Oh! ", imageURL))
  }
  render () {
    return (
      <div className='App-Page1'>
        {this.state.images.map((item, i) => {
          console.log('WTF: ', item.src, 'i: ', item.class)
          if (item.class == 'selection1') {
            return (
              <Link to='/Page2'>
                <img src={item.src} className={'App-' + item.class} />
              </Link>
            )
          } else {
            return <img src={item.src} className={'App-' + item.class} />
          }
        })}
        {/* <img src={this.state.images[0]} className='App-background1' />
        <img src={this.state.images[1]} className='App-box1' />
        <img src={this.state.images[2]} className='App-icon1' />
        <img src={this.state.images[3]} className='App-icon2' />
        <img src={this.state.images[4]} className='App-picture1' />
        <Link to='/Page2'>
          <img src={this.state.images[5]} className='App-selection1' />
        </Link>
        <img src={this.state.images[6]} className='App-selection2' />
        <img src={this.state.images[7]} className='App-selection3' />
        <img src={this.state.images[8]} className='App-sentence1' />
        <img src={this.state.images[9]} className='App-special_icon1' />
        <img src={this.state.images[10]} className='App-special_icon2' />
        <img src={this.state.images[11]} className='App-title1' /> */}

        {/* <img src={background} className='App-background1' alt='background1' />
        <img src={box1} className='App-box1' alt='box1' />
        <img src={icon1} className='App-icon1' alt='icon1' />
        <img src={icon2} className='App-icon2' alt='icon2' />
        <img src={picture} className='App-picture1' alt='picture1' />
        <img
          src={special_icon1}
          className='App-special_icon1'
          alt='special_icon1'
        />
        <img
          src={special_icon2}
          className='App-special_icon2'
          s
          alt='special_icon2'
        />
        <img src={title} className='App-title1' alt='title1' />
        <img src={subtitle} className='App-sentence1' alt='sentence1' />
        <Link to='/Page2'>
          <img
            src={selection1}
            className='App-selection1'
            alt='selection1'
            // onClick={() => {
            //   document.body.style.backgroundImage =
            //     'url("' + images['cache4'] + '")'
            // }}
          />
        </Link>
        <img src={selection2} className='App-selection2' alt='selection2' />
        <img src={selection3} className='App-selection3' alt='selection3' /> */}
      </div>
    )
  }
}
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<Page1 />)
export default Page1

import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { importAll, importRes } from './index'
import './resources/sass/App.sass'

class Page4 extends React.Component {
  constructor (props) {
    super(props)
    let imagesURL = importAll(
      require.context('./resources/images_avif/Page4/', false, /\.(avif|svg|png|jpe?g)$/)
    )
    let sentences = sessionStorage.getItem('sentences')
    let words = JSON.parse(sessionStorage.getItem('words'))
    this.state = { images: importRes('image', imagesURL), words: words }
  }

  componentDidMount () {
    const intervalId = setInterval(() => {
      this.setState(prevState => {
        let words = JSON.parse(sessionStorage.getItem('words'))
        if (words && words[0].char != null) {
          clearInterval(intervalId)
        }
        return {
          words: words
        }
      })
    }, 40)
  }

  render () {
    clearInterval(this.intervalId)
    return (
      <div className='App-Page4'>
        {this.state.images.map(item => {
          switch (item.class) {
            case 'icon1':
              return (
                <Link to='/Page3'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            default:
              return <img src={item.src} className={'App-' + item.class} />
          }
        })}
        <div className='App-subtitle2'>
          {this.state.words
            ? this.state.words.map((item, index) => {
                let color = {},
                  img_src = '',
                  img_className = ''
                if (item.score < 60 && item.score != 0) {
                  color = {
                    color: '#F55D5E'
                  }
                  img_src = this.state.images[5].src
                  img_className = 'App-mark1'
                } else if (item.score == 0) {
                  color = {
                    color: '#00CAFF'
                  }
                  img_src = this.state.images[6].src
                  img_className = 'App-mark2'
                }
                return (
                  <span className='word' key={index} style={color}>
                    <span>{item.score}</span>
                    <span>{item.char || item.txt}</span>
                    <img src={img_src} className={img_className} />
                  </span>
                )
              })
            : {}}
        </div>
      </div>
    )
  }
}

export default Page4

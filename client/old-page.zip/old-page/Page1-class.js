import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { importAll, importRes } from '../index'
import './resources/sass/App.sass'
class Page1 extends React.Component {
  constructor (props) {
    super(props)
    let imagesURL = importAll(
      require.context('./resources/images_avif/Page1/', false, /\.(avif|svg|png|jpe?g)$/)
    )
    this.state = { images: importRes('image', imagesURL) }
  }

  componentDidMount () {}

  render () {
    return (
      <div className='App-Page1'>
        {this.state.images.map(item => {
          switch (item.class) {
            case 'selection1':
              return (
                <Link to='/Page2'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            default:
              return <img src={item.src} className={'App-' + item.class} />
          }
        })}
      </div>
    )
  }
}

export default Page1

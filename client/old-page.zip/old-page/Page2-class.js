import React, { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { importAll, importRes } from './index'

/* import Chivox component */
import Html5Player from 'chivox_h5sdk/src/html5/html5player'
import Html5Recorder from 'chivox_h5sdk/src/html5/html5recorder'
import './resources/sass/App.sass'

class Page2 extends React.Component {
  constructor (props) {
    super(props)
    let imagesURL = importAll(
      require.context('./resources/images_avif/Page2/', false, /\.(avif|svg|png|jpe?g)$/)
    )
    let voicesURL = importAll(
      require.context('./resources/voices/', false, /\.(wav|mp3)$/)
    )
    console.log('voicesURL: ' + voicesURL)
    this.state = {
      images: importRes('image', imagesURL),
      refText: 'Once upon a time, there lived three little pigs. ',
      refAudio: new Audio(voicesURL[0]),
      recorder: [
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Sentence Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        }),
        new Html5Recorder({
          server: 'wss://cloud.chivox.com',
          appKey: '1649755076000093',
          sigurl: '/key',
          onInit: mess => {
            console.log('Free Scoring API onInit success')
          },
          onError: err => {
            console.log('onError: ' + err)
          }
        })
      ],
      audio: new Audio(voicesURL[0]),
      recordFlag: true
    }
    // Bind click function
    this.handleClick1 = this.handleClick1.bind(this)
    this.handleClick2 = this.handleClick2.bind(this)
  }

  componentDidMount (props) {}

  // Click: Next page
  handleClick1 () {
    document.querySelector(
      '.Story-Page[style * ="display:initial;"]'
    ).style.display = 'none'
    console.log(
      document.querySelector(
        '.Story-Page[style * ="display:initial;"] + .Story-Page'
      )
    )
  }

  // Click: Record
  handleClick2 () {
    console.log('Button clicked')
    // Play audio
    this.state.refAudio.play()
    console.log(this.state.refAudio.duration)
    // Recording after audio
    setTimeout(() => {
      if (this.state.recordFlag) {
        this.state.recordFlag = false
        // Calling Sentence Scoring Interface
        this.state.recorder[0].stopRecord()
        this.state.recorder[0].record({
          duration: 8000,
          playDing: true,
          serverParams: {
            coreType: 'en.sent.score',
            refText: this.state.refText,
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
          },
          onStop: () => {
            console.log('onStop')
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            console.log(JSON.stringify(score.result.details))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem(
              'words',
              JSON.stringify(score.result.details)
            )
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
            // Integrity
            sessionStorage.setItem('integrity', score.result.integrity)
            // Accuracy
            sessionStorage.setItem('accuracy', score.result.accuracy)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[0].stopRecord()
            this.state.recorder[0].reset()
            alert(JSON.stringify(err))
          }
        })

        // Calling the Free Scoring Interface
        this.state.recorder[1].stopRecord()
        this.state.recorder[1].record({
          duration: 8000,
          playDing: false,
          serverParams: {
            coreType: 'en.asr.rec',
            res: 'en.asr.G4',
            rank: 100,
            userId: 'tester',
            attachAudioUrl: 1,
            result: {
              details: {
                ext_cur_wrd: 1
              }
            }
          },
          onRecordIdGenerated: tokenId => {
            console.log('========onRecordIdGenerated start========')
            console.log(JSON.stringify(tokenId))
            console.log('========onRecordIdGenerated end========')
          },
          onStart: () => {
            console.log('onStart')
            sessionStorage.clear()
          },
          onStop: () => {
            console.log('onStop')
          },
          onInternalScore: score => {
            console.log('onInternalScore')
            console.log(JSON.stringify(score.result.align))
            // Sentences
            sessionStorage.setItem('sentences', this.state.refText)
            // Words
            sessionStorage.setItem('words', JSON.stringify(score.result.align))
            // Score
            sessionStorage.setItem('score', score.result.overall)
            // Fluency
            sessionStorage.setItem('fluency', score.result.fluency.overall)
          },
          onScore: score => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            // console.log(score.result)
          },
          onScoreError: err => {
            this.state.recordFlag = true
            this.state.recorder[1].stopRecord()
            this.state.recorder[1].reset()
            alert(JSON.stringify(err))
          }
        })
      } else {
        this.state.recordFlag = true
        this.state.recorder[1].stopRecord()
        console.log('record stop.')
      }
    }, this.state.refAudio.duration * 1.3 * 1000 || 0) /* Delay 1.3 time before calling Chivox API */
  }

  render () {
    return (
      <div className='App-Page2'>
        {this.state.images.map(item => {
          switch (item.class) {
            case 'icon3':
              return (
                <Link to='/'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            case 'icon5':
            case 'icon6':
              return (
                <img
                  src={item.src}
                  className={'App-' + item.class}
                  onClick={
                    item.class == 'icon5'
                      ? this.handleClick1
                      : this.handleClick2
                  }
                />
              )
            case 'pig6':
              return (
                <Link to='/Page3'>
                  <img src={item.src} className={'App-' + item.class} />
                </Link>
              )
            default:
              return <img src={item.src} className={'App-' + item.class} />
          }
        })}
      </div>
    )
  }
}

export default Page2
